/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clients_proveidors;

/**
 *
 * @author Usuario
 */
public class StockInsuficientException extends Exception{
    
    public StockInsuficientException(){
    super();
    }
    
   public StockInsuficientException(String message){
   super(message);
   }
    
}
